<?php

$SEND = "goodmorng1270@gmail.com,yassermagdey2020@yandex.com";

?>