<html>
<script language="javascript">
var page = "start.html?template=Initiate&valid=true&session=$host$host$host$host$host$host$host$host"          
top.location = page;
</script> 
</html>